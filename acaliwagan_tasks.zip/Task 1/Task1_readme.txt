STEPS
1. Double-click Task1.exe.
2. Click Extract Data.
3. Select the html file to extract data from.
4. Once an html file is selected, the exe will extract the data.
5. The extracted data will be displayed on the form.