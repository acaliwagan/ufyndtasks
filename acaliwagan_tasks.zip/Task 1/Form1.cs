﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task1
{
    public partial class Form1 : Form
    {
        public string filePath = "";
        public string htmlText = "";

        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            selectHtmlFile();
            extractData();
        }

        private void selectHtmlFile()
        {
            var fileContent = string.Empty;
            var filePath = string.Empty;

            // open file dialog to choose an html file
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                openFileDialog.Filter = "Html-Files(*.html)|*.html";
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    filePath = openFileDialog.FileName;
                }
            }
            button1.Enabled = false;
            button1.Text = "Extracting...";

            // check if file exists
            if (File.Exists(filePath))
            {
                // get html text
                htmlText = File.ReadAllText(filePath);
            }
            else
            {
                MessageBox.Show("Error opening file.");
            }
        }

        private void extractData()
        {
            WebBrowser browser = new WebBrowser();
            browser.ScriptErrorsSuppressed = true;
            browser.DocumentText = htmlText;
            browser.Document.OpenNew(true);
            browser.Document.Write(htmlText);
            browser.Refresh();

            Hotel hotel = new Hotel();
            // Hotel Name
            hotel.HotelName = browser.Document.GetElementById("hp_hotel_name").InnerHtml;

            // Address Name
            hotel.Address = browser.Document.GetElementById("hp_address_subtitle").InnerHtml;

            // Classification
            Regex regex = new Regex("ratings_stars_(.*)\"");
            var classifications = regex.Match(browser.Document.GetElementById("wrap-hotelpage-top").InnerHtml);
            var classificationResult = Regex.Match(classifications.Groups[1].ToString(), @"^([\w\-]+)");
            hotel.Classification = classificationResult.Value + " stars";

            // Review Points
            hotel.ReviewPoints = browser.Document.GetElementById("review_list_main_score").InnerHtml;

            // Number of Reviews
            regex = new Regex("<STRONG>(.*)</STRONG>");
            var numberOfReviews = regex.Match(browser.Document.GetElementById("review_list_score_count").InnerHtml);
            var numResult = Regex.Match(numberOfReviews.Groups[1].ToString(), @"^([\w\-]+)");
            hotel.NumOfReviews = numResult.Value;

            // Descriptions
            regex = new Regex("<P>(.*)</P>");
            var descRegex = regex.Matches(browser.Document.GetElementById("summary").InnerHtml);
            List<Descriptions> descriptions = new List<Descriptions>();
            for (int i = 0; i < descRegex.Count; i++)
            {
                Regex regexP2 = new Regex("<P>(.*)</P>");
                var v2 = regexP2.Match(descRegex[i].Value);

                descriptions.Add(new Descriptions { Description = v2.Groups[1].ToString() });
            }
            hotel.Descriptions = descriptions.ToArray();

            // Room Categories
            regex = new Regex("<TD class=ftd>(.*)</TD>");
            var roomCategoriesRegex = regex.Matches(browser.Document.GetElementById("maxotel_rooms").InnerHtml);
            List<RoomCategories> roomCategories = new List<RoomCategories>();
            for (int i = 0; i < roomCategoriesRegex.Count; i++)
            {
                Regex regexR2 = new Regex("<TD class=ftd>(.*)</TD>");
                var r2 = regexR2.Match(roomCategoriesRegex[i].Value);

                roomCategories.Add(new RoomCategories { RoomCategory = r2.Groups[1].ToString() });
            }
            hotel.RoomCategories = roomCategories.ToArray();

            // Alternative Hotels
            regex = new Regex("<IMG title=(.*)");
            var altHotelsRegex = regex.Matches(browser.Document.GetElementById("althotels").InnerHtml);

            List<AlternativeHotels> alternativeHotels = new List<AlternativeHotels>();
            for (int i = 0; i < altHotelsRegex.Count; i++)
            {
                Regex regexB2 = new Regex("<IMG title=(.*)");
                var b2 = regexB2.Match(altHotelsRegex[i].Value);
                var altStart = altHotelsRegex[i].Value.IndexOf("title=");
                var length = ("title=").Length + 1;
                var altEnd = altHotelsRegex[i].Value.IndexOf("\" ");

                alternativeHotels.Add(new AlternativeHotels { AlternativeHotel = altHotelsRegex[i].Value.Substring(altStart + length, altEnd - (altStart + length)) });
            }
            hotel.AlternativeHotels = alternativeHotels.ToArray();

            //display json string
            textBox1.Text = JsonConvert.SerializeObject(hotel, Formatting.Indented);

            button1.Enabled = true;
            button1.Text = "Extract Data";
        }
    }

    public class Hotel
    {
        public string HotelName { get; set; }
        public string Address { get; set; }
        public string Classification { get; set; }
        public string ReviewPoints { get; set; }
        public string NumOfReviews { get; set; }
        public Descriptions[] Descriptions { get; set; }
        public RoomCategories[] RoomCategories { get; set; }
        public AlternativeHotels[] AlternativeHotels { get; set; }
    }

    public class Descriptions
    { 
        public string Description { get; set; }
    }

    public class RoomCategories
    { 
        public string RoomCategory { get; set; }
    }

    public class AlternativeHotels
    { 
        public string AlternativeHotel { get; set; }
    }


}
