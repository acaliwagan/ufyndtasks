STEPS
1. Double-click Task2.exe.
2. Click Select Json File.
3. Select the json file.
4. Once a json file is selected, the exe will create an Excel file.
5. Once done, a link to the Excel file created will be displayed.
6. Click the link to open the file.
7. The extracted data from the json file will be shown in spreadsheet form.

Optional Task: Suggest an architecture on how to automate the process that an 
email is sent at time x attaching the report
 - I would suggest using a job scheduler library, like hangfire. A background job (that sends an email with the report as attachment) can be scheduled at a specific time.