﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Task2
{
    public partial class Form1 : Form
    {

        public object objects = null;
        public string openFile = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            selectJsonFile();
            parseJson();
            writeToExcel();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments), linkLabel1.Text));
        }

        private void selectJsonFile()
        {
            var fileContent = string.Empty;
            var filePath = string.Empty;

            // open file dialog to choose a json file
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                openFileDialog.Filter = "Json files (*.json)|*.json";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    openFile = openFileDialog.FileName;
                }
            }
            linkLabel1.Visible = false;
            button1.Enabled = false;
            button1.Text = "Processing...";
        }

        private void parseJson()
        {
            // parse json file
            var jsonText = System.IO.File.ReadAllText(openFile);
            objects = JsonConvert.DeserializeObject<Rootobject>(jsonText);

        }

        private void writeToExcel()
        {
            string fileName, filePath;
            try
            {
                Excel.Application objApp;
                Excel.Workbook objBook;
                Excel.Worksheet objSheet;

                objApp = new Excel.Application();
                objBook = objApp.Workbooks.Add(System.Reflection.Missing.Value);
                objSheet = objBook.Sheets.Add();

                // add xls headings
                objSheet.Cells[1, 1].Value = "ARRIVAL_DATE";
                objSheet.Cells[1, 2].Value = "DEPARTURE_DATE";
                objSheet.Cells[1, 3].Value = "PRICE";
                objSheet.Cells[1, 4].Value = "CURRENCY";
                objSheet.Cells[1, 5].Value = "RATENAME";
                objSheet.Cells[1, 6].Value = "ADULTS";
                objSheet.Cells[1, 7].Value = "BREAKFAST_IN";

                var data = ((Task2.Rootobject)objects).hotelRates;

                if (data != null && data.Length > 0)
                {
                    for (int i = 2; i < data.Length; i++)
                    {
                        //set value of cell
                        objSheet.Cells[i, 1].Value = data[i].targetDay.ToString("dd.MM.yy");
                        objSheet.Cells[i, 2].Value = Convert.ToDateTime(data[i].targetDay).AddDays(data[i].los).ToString("dd.MM.yy");
                        objSheet.Cells[i, 3].Value = data[i].price.numericFloat.ToString("#.00").Replace(".", ",");
                        objSheet.Cells[i, 4].Value = data[i].price.currency.ToString();
                        objSheet.Cells[i, 5].Value = data[i].rateName;
                        objSheet.Cells[i, 6].Value = data[i].adults;
                        objSheet.Cells[i, 7].Value = data[i].rateTags[0].shape == true ? 1 : 0;
                    }
                }

                objSheet.Columns.AutoFit();

                // save excel file
                fileName = "Results" + DateTime.Now.ToString("ddMMyyhhmm") + ".xlsx";
                filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments), fileName);

                objSheet.SaveAs(filePath);
                objBook.Close();
                objApp.Quit();

                linkLabel1.Text = fileName;
                linkLabel1.Visible = true;
                button1.Enabled = true;
                button1.Text = "Select Json File";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }

    public class Rootobject
    {
        public Hotel hotel { get; set; }
        public Hotelrate[] hotelRates { get; set; }
    }

    public class Hotel
    {
        public int hotelID { get; set; }
        public int classification { get; set; }
        public string name { get; set; }
        public float reviewscore { get; set; }
    }

    public class Hotelrate
    {
        public int adults { get; set; }
        public int los { get; set; }
        public Price price { get; set; }
        public string rateDescription { get; set; }
        public string rateID { get; set; }
        public string rateName { get; set; }
        public Ratetag[] rateTags { get; set; }
        public DateTime targetDay { get; set; }
    }

    public class Price
    {
        public string currency { get; set; }
        public float numericFloat { get; set; }
        public int numericInteger { get; set; }
    }

    public class Ratetag
    {
        public string name { get; set; }
        public bool shape { get; set; }
    }

}
